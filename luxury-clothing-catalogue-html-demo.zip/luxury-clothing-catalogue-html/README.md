# Luxury Interactive Clothing Catalogue — HTML Demo

A mobile-first, static HTML/CSS/JavaScript catalogue inspired by the supplied brief. Includes category filters, product cards, product detail overlay, WhatsApp enquiry links, responsive layout and subtle Liquid Glass styling.

## Important demo note
The six products, shop name, prices, descriptions, contact number and remote sample photos are placeholders. Replace them before sharing with customers. Do not present the sample data as real inventory.

## Edit your shop and products
Open `products.js` and change:
- `SHOP.name` — shop name
- `SHOP.whatsapp` — full international number, digits only (no `+` or spaces)
- `SHOP.instagram` — optional; reserved for future social link
- `PRODUCTS` — add/edit/remove product objects

Each product supports: `id`, `name`, `category`, `code`, `price`, `sizes`, `colours`, `fabric`, `description`, and `image`.

For reliable hosting, upload product photos into `assets/` and set image paths like `assets/product-01.jpg`. You can add up to 30 products; the grid adapts automatically.

## Test locally
Open `index.html` in a browser. For the best experience, use a simple static server or GitHub Pages. The demo uses Google Fonts and remote Unsplash sample images, so those sample assets require an internet connection.

## Publish free with GitHub Pages (Android-friendly)
1. Extract this ZIP on your device.
2. Create a new public GitHub repository, e.g. `clothing-catalogue`.
3. Upload the *contents* of this folder to the repository root. Make sure `index.html`, `products.js`, `styles.css`, and `.github/workflows/deploy.yml` are at the top-level / expected paths (not nested inside another folder).
4. Commit the files to the `main` branch.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment → Source**, choose **GitHub Actions**. Do not choose “Deploy from a branch”.
7. Open **Actions**. The “Deploy catalogue to GitHub Pages” workflow should run after the push. Wait until it shows a green check.
8. Open **Settings → Pages** again; the published URL appears there. It will usually look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## If the workflow does not run
- Confirm the workflow file is exactly `.github/workflows/deploy.yml`.
- Confirm the default branch is `main`, or change the `branches` value in the YAML to your branch.
- Confirm Pages source is set to **GitHub Actions**.
- In **Settings → Actions → General**, ensure workflows are permitted to run. The default setting is normally sufficient.
- Check the Actions run log for the first red step.

## Before launch checklist
- [ ] Replace ATELIER with the real shop name.
- [ ] Set the real WhatsApp number with country code.
- [ ] Replace all six sample products and sample image URLs.
- [ ] Add real product photos to `assets/`.
- [ ] Verify product codes, prices, sizes, colours and fabric details.
- [ ] Test every product detail and WhatsApp order button on Android.
- [ ] Share the published link only after replacing demo data.

## What this HTML version does
Unlike the PDF brief, this is a live web catalogue: the filters, detail view and WhatsApp links are interactive, and product information can be updated in `products.js`. It does not generate a PDF.
