/*
  EDIT YOUR CATALOGUE HERE.
  Replace the demo products with your real products.
  For each image, use a file in assets/ (example: "assets/your-product.jpg")
  or a publicly accessible image URL.
  Never leave demo prices/details in a real customer catalogue.
*/
const SHOP = {
  name: "ATELIER",
  whatsapp: "919876543210", // Replace with country code + number, digits only. Example India: 91XXXXXXXXXX
  instagram: ""
};

const PRODUCTS = [
  {id:"AT-001",name:"The Sculpted Blazer",category:"Women",code:"AT-001",price:"₹3,490",sizes:"XS, S, M, L",colours:"Sand, Black",fabric:"Linen blend",description:"A clean, relaxed silhouette with considered tailoring and a softly structured shoulder.",image:"https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=1000&q=85"},
  {id:"AT-002",name:"Everyday Form Shirt",category:"Men",code:"AT-002",price:"₹1,890",sizes:"S, M, L, XL",colours:"Ivory, Stone",fabric:"Cotton",description:"An understated essential designed for effortless everyday dressing.",image:"https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=1000&q=85"},
  {id:"AT-003",name:"The Weekend Set",category:"Casual",code:"AT-003",price:"₹2,750",sizes:"S, M, L",colours:"Olive, Ecru",fabric:"Cotton twill",description:"An easy two-piece set with a relaxed fit and versatile styling.",image:"https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1000&q=85"},
  {id:"AT-004",name:"Soft Structure Dress",category:"Women",code:"AT-004",price:"₹2,990",sizes:"XS, S, M, L",colours:"Black, Cocoa",fabric:"Viscose blend",description:"A fluid shape balanced by precise details. Made for day-to-evening wear.",image:"https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85"},
  {id:"AT-005",name:"Modern Classic",category:"Men",code:"AT-005",price:"₹2,250",sizes:"M, L, XL",colours:"Charcoal, Beige",fabric:"Premium cotton",description:"A modern wardrobe staple with a timeless profile and comfortable finish.",image:"https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=85"},
  {id:"AT-006",name:"The Essential Layer",category:"Casual",code:"AT-006",price:"₹1,650",sizes:"S, M, L, XL",colours:"Cream, Grey",fabric:"Cotton jersey",description:"A versatile layer that works across seasons and occasions.",image:"https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1000&q=85"}
];