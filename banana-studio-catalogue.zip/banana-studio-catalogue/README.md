# Banana Studio — Pants Collection Catalogue

A premium, single-page HTML catalogue in a liquid-glass design (beige & olive).
Home page → **Our Collection** → 14 numbered cards → each card opens an elegant glass popup.

No build tools, no dependencies — plain HTML, CSS and JS.

## Put it online with GitHub Pages

1. Create a new GitHub repository (e.g. `banana-studio-catalogue`).
2. Upload everything from this folder (keep the `.github` folder — it contains `build.yml`).
3. In the repository go to **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**.
4. Push to `main`. The workflow in `.github/workflows/build.yml` publishes the site.
   Your link will be `https://<your-username>.github.io/<repository-name>/`.

> Prefer no Actions? Set **Source: Deploy from a branch → main / (root)** instead. The site works either way.

## Adding details for each pant

Open `js/products.js`. Every pant has a number (`id: 1` … `id: 14`) with these fields:

```js
{
  id: 5,
  name: "Pant 05",                 // title shown on the card and popup
  image: "assets/images/pant-05.jpg",
  description: "Short paragraph…", // optional
  specs: {
    "Fabric": "12 oz cotton denim",
    "Fit": "Relaxed straight",
    "MOQ": "500 pcs"
    // …anything left "" shows as "—"
  }
}
```

You can rename, add or remove spec rows freely. To show an **Enquire** button in every popup,
set `enquiryEmail` at the top of the same file.

## Replacing an image

Overwrite the file in `assets/images/` (keep the same name, JPG recommended, ~1000 px wide).

## Structure

```
index.html
css/style.css
js/products.js      ← edit your details here
js/app.js
assets/logo.png
assets/images/pant-01.jpg … pant-14.jpg
.github/workflows/build.yml
```
