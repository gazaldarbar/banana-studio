/* ==========================================================
   BANANA STUDIO — Catalogue behaviour
   Views: home → collection → popup (with hash routing)
     #            home
     #collection  grid of 14 cards
     #style-05    popup for card 05
   ========================================================== */
(function () {
  "use strict";

  var CFG = window.BANANA_CONFIG || {};
  var DATA = window.PRODUCTS || [];
  var TOTAL = DATA.length;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var pad = function (n) { return String(n).padStart(2, "0"); };
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var el = {
    home: $("#home"), collection: $("#collection"), grid: $("#grid"),
    enter: $("#enter"), homeLink: $("#home-link"),
    modal: $("#modal"), panel: $(".modal__panel"), body: $("#m-body"),
    img: $("#m-img"), chip: $("#m-chip"), count: $("#m-count"), title: $("#m-title"),
    desc: $("#m-desc"), specs: $("#m-specs"), enquire: $("#m-enquire"),
    prev: $("#m-prev"), next: $("#m-next")
  };

  var state = { index: -1, open: false, pushed: false, lastCard: null, closing: false };

  /* ---------- Static text from config ---------- */
  if ($("#season")) $("#season").textContent = CFG.season || "2026";
  if ($("#year")) $("#year").textContent = new Date().getFullYear();
  document.querySelectorAll(".topbar__count, .hero__meta span:first-child").forEach(function (n) {
    n.textContent = TOTAL + " Styles";
  });

  /* ---------- Build the grid ---------- */
  var arrowSvg = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

  DATA.forEach(function (p, i) {
    var li = document.createElement("li");
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "card";
    btn.style.setProperty("--i", i);
    btn.setAttribute("aria-label", "Open " + p.name);
    btn.dataset.index = i;
    btn.innerHTML =
      '<span class="card__img"><img src="' + (p.thumb || p.image) + '" alt="' + p.name + '" decoding="async" style="object-position:' + (p.position || "center") + '"></span>' +
      '<span class="card__num">' + pad(p.id) + '</span>' +
      '<span class="card__name"><span>' + p.name + '</span><span class="card__arrow">' + arrowSvg + '</span></span>';
    li.appendChild(btn);
    el.grid.appendChild(li);

    btn.addEventListener("click", function () {
      state.lastCard = btn;
      state.pushed = true;
      location.hash = "style-" + pad(p.id);
    });
    btn.addEventListener("pointermove", function (e) {
      var r = btn.getBoundingClientRect();
      btn.style.setProperty("--mx", (e.clientX - r.left) + "px");
      btn.style.setProperty("--my", (e.clientY - r.top) + "px");
    });
  });
  var cards = Array.prototype.slice.call(el.grid.querySelectorAll(".card"));

  /* ---------- View switching ---------- */
  var currentView = "home";

  function setView(name) {
    if (name === currentView) return;
    var cur = currentView === "home" ? el.home : el.collection;
    var next = name === "home" ? el.home : el.collection;
    currentView = name;
    document.body.dataset.view = name;
    window.scrollTo(0, 0);

    cur.classList.remove("is-active");
    cur.classList.add("is-leaving");
    cur.setAttribute("inert", "");
    setTimeout(function () {
      if (cur.classList.contains("is-active")) return;
      cur.classList.remove("is-leaving");
      cur.hidden = true;
    }, reduceMotion ? 0 : 650);

    next.hidden = false;
    next.removeAttribute("inert");
    if (name === "collection") cards.forEach(function (c) { c.classList.remove("in"); });
    void next.offsetWidth; // force reflow so the transition runs from the hidden state
    next.classList.add("is-active");
    if (name === "collection") {
      setTimeout(function () { cards.forEach(function (c) { c.classList.add("in"); }); }, 120);
    }
  }

  /* ---------- Popup ---------- */
  function fillContent(i) {
    var p = DATA[i];
    state.index = i;
    el.img.src = p.image;
    el.img.alt = p.name;
    el.img.style.objectPosition = p.position || "center";
    el.chip.textContent = "No. " + pad(p.id);
    el.count.textContent = "Style " + pad(p.id) + " / " + pad(TOTAL);
    el.title.textContent = p.name;
    el.desc.textContent = p.description || "";

    el.specs.innerHTML = "";
    var specs = p.specs || {};
    Object.keys(specs).forEach(function (k) {
      var row = document.createElement("div");
      var dt = document.createElement("dt");
      var dd = document.createElement("dd");
      dt.textContent = k;
      var v = (specs[k] || "").toString().trim();
      if (!v) return; // empty fields are simply not shown
      dd.textContent = v;
      row.appendChild(dt); row.appendChild(dd);
      el.specs.appendChild(row);
    });

    if (CFG.enquiryEmail) {
      el.enquire.hidden = false;
      el.enquire.href = "mailto:" + CFG.enquiryEmail +
        "?subject=" + encodeURIComponent("Enquiry — " + p.name + " (Style " + pad(p.id) + ")");
    } else {
      el.enquire.hidden = true;
    }
    el.body.scrollTop = 0;

    // warm the neighbours
    [i - 1, i + 1].forEach(function (j) {
      var q = DATA[(j + TOTAL) % TOTAL]; if (q) { var im = new Image(); im.src = q.image; }
    });
  }

  function cardRectIfVisible(i) {
    var c = cards[i];
    if (!c) return null;
    var r = c.getBoundingClientRect();
    if (r.bottom < 0 || r.top > window.innerHeight || r.width === 0) return null;
    return r;
  }

  function openModal(i) {
    if (state.closing) return;
    var wasOpen = state.open;
    if (wasOpen) { goTo(i, i > state.index ? 1 : -1, true); return; }

    fillContent(i);
    state.open = true;
    el.modal.hidden = false;
    document.documentElement.classList.add("modal-open"); document.body.classList.add("modal-on");
    el.home.setAttribute("inert", ""); el.collection.setAttribute("inert", "");

    requestAnimationFrame(function () {
      el.modal.classList.add("is-open");
      var from = cardRectIfVisible(i);
      var to = el.panel.getBoundingClientRect();
      if (!reduceMotion && el.panel.animate) {
        var kf;
        if (from) {
          var s = Math.max(from.width / to.width, 0.2);
          var dx = (from.left + from.width / 2) - (to.left + to.width / 2);
          var dy = (from.top + from.height / 2) - (to.top + to.height / 2);
          kf = [
            { transform: "translate(" + dx + "px," + dy + "px) scale(" + s + ")", opacity: 0, filter: "blur(10px)" },
            { opacity: 1, offset: .35 },
            { transform: "none", opacity: 1, filter: "blur(0)" }
          ];
        } else {
          kf = [
            { transform: "translateY(40px) scale(.94)", opacity: 0, filter: "blur(10px)" },
            { transform: "none", opacity: 1, filter: "blur(0)" }
          ];
        }
        el.panel.animate(kf, { duration: 720, easing: "cubic-bezier(.22,.8,.24,1)" });
      } else {
        el.panel.style.opacity = 1;
      }
      setTimeout(function () { el.panel.focus({ preventScroll: true }); }, 80);
    });
  }

  function closeModal(done) {
    if (!state.open || state.closing) { if (done) done(); return; }
    state.closing = true;
    el.modal.classList.remove("is-open");

    var finish = function () {
      el.modal.hidden = true;
      el.panel.style.opacity = "";
      state.open = false; state.closing = false; state.pushed = false;
      document.documentElement.classList.remove("modal-open"); document.body.classList.remove("modal-on");
      el.collection.removeAttribute("inert");
      var c = cards[state.index];
      if (c) c.focus({ preventScroll: true });
      if (done) done();
    };

    if (!reduceMotion && el.panel.animate) {
      var from = cardRectIfVisible(state.index);
      var to = el.panel.getBoundingClientRect();
      var end = from
        ? { transform: "translate(" + ((from.left + from.width / 2) - (to.left + to.width / 2)) + "px," + ((from.top + from.height / 2) - (to.top + to.height / 2)) + "px) scale(" + Math.max(from.width / to.width, .2) + ")", opacity: 0, filter: "blur(8px)" }
        : { transform: "translateY(30px) scale(.96)", opacity: 0, filter: "blur(8px)" };
      var a = el.panel.animate([{ transform: "none", opacity: 1, filter: "blur(0)" }, end],
        { duration: 480, easing: "cubic-bezier(.4,0,.2,1)", fill: "both" });
      a.onfinish = function () { a.cancel(); finish(); };
    } else {
      finish();
    }
  }

  function goTo(i, dir, fromRoute) {
    i = (i + TOTAL) % TOTAL;
    if (i === state.index) return;
    var d = dir || 1;
    if (!reduceMotion && el.img.animate) {
      el.img.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateX(" + (-d * 26) + "px) scale(1.03)" }],
        { duration: 180, easing: "ease-in", fill: "forwards" }).onfinish = function () {
        fillContent(i);
        el.img.getAnimations().forEach(function (a) { a.cancel(); });
        el.img.animate([{ opacity: 0, transform: "translateX(" + (d * 26) + "px) scale(1.03)" }, { opacity: 1, transform: "none" }],
          { duration: 460, easing: "cubic-bezier(.22,.8,.24,1)" });
      };
      el.body.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateX(" + (-d * 18) + "px)" }, { opacity: 0, transform: "translateX(" + (d * 18) + "px)", offset: .5 }, { opacity: 1, transform: "none" }],
        { duration: 640, easing: "cubic-bezier(.22,.8,.24,1)" });
    } else {
      fillContent(i);
    }
    if (!fromRoute) history.replaceState(history.state, "", "#style-" + pad(DATA[i].id));
  }

  /* ---------- Routing ---------- */
  function parseHash() {
    var h = location.hash.replace("#", "");
    var m = /^style-(\d{1,2})$/.exec(h);
    if (m) {
      var idx = DATA.findIndex(function (p) { return p.id === parseInt(m[1], 10); });
      if (idx > -1) return { view: "collection", modal: idx };
    }
    if (h === "collection") return { view: "collection", modal: -1 };
    return { view: "home", modal: -1 };
  }

  function route() {
    var r = parseHash();
    if (r.modal > -1) {
      setView("collection");
      openModal(r.modal);
    } else {
      var go = function () { setView(r.view); };
      if (state.open) closeModal(go); else go();
    }
  }
  window.addEventListener("hashchange", route);

  function requestClose() {
    if (!state.open) return;
    if (state.pushed) { history.back(); }
    else { history.replaceState(null, "", "#collection"); closeModal(); }
  }

  /* ---------- Events ---------- */
  el.enter.addEventListener("click", function () { location.hash = "collection"; });
  el.homeLink.addEventListener("click", function () { location.hash = ""; if (!location.hash) route(); });

  el.modal.addEventListener("click", function (e) {
    if (e.target.closest("[data-close]")) requestClose();
  });
  el.prev.addEventListener("click", function () { goTo(state.index - 1, -1); });
  el.next.addEventListener("click", function () { goTo(state.index + 1, 1); });

  document.addEventListener("keydown", function (e) {
    if (!state.open) return;
    if (e.key === "Escape") { e.preventDefault(); requestClose(); }
    else if (e.key === "ArrowLeft") goTo(state.index - 1, -1);
    else if (e.key === "ArrowRight") goTo(state.index + 1, 1);
    else if (e.key === "Tab") { // focus trap
      var f = el.panel.querySelectorAll('button:not([hidden]), a[href]:not([hidden])');
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === el.panel)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  // swipe left / right on touch devices
  var tx = 0, ty = 0;
  el.panel.addEventListener("touchstart", function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  el.panel.addEventListener("touchend", function (e) {
    var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
    if (Math.abs(dx) > 70 && Math.abs(dy) < 60) goTo(state.index + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1);
  }, { passive: true });

  /* ---------- Start ---------- */
  if (location.hash) route();
})();
