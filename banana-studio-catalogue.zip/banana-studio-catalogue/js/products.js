/* ==========================================================
   BANANA STUDIO — CATALOGUE DATA
   ----------------------------------------------------------
   This is the ONLY file you need to edit to add details.
   Each pant is numbered 1–14. Fill in the fields you want;
   anything left as "" shows as "—" in the popup.
   ========================================================== */

window.BANANA_CONFIG = {
  company: "Banana Studio",
  tagline: "Garments Exporting Company",
  collectionTitle: "Pants Collection",
  season: "2026",
  // Add an email to show an "Enquire about this style" button in every popup.
  // Leave empty ("") to hide the button.
  enquiryEmail: ""
};

window.PRODUCTS = [
  {
    id: 1,
    name: "Pant 01",
    image: "assets/images/pant-01.jpg",
    position: "center 45%",
    description: "",
    specs: {
      "Fabric": "",
      "Composition": "",
      "Fit": "",
      "Colour": "",
      "Wash / Finish": "",
      "Size Range": "",
      "MOQ": "",
      "Packing": ""
    }
  },
  {
    id: 2,
    name: "Pant 02",
    image: "assets/images/pant-02.jpg",
    position: "center 50%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 3,
    name: "Pant 03",
    image: "assets/images/pant-03.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 4,
    name: "Pant 04",
    image: "assets/images/pant-04.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 5,
    name: "Pant 05",
    image: "assets/images/pant-05.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 6,
    name: "Pant 06",
    image: "assets/images/pant-06.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 7,
    name: "Pant 07",
    image: "assets/images/pant-07.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 8,
    name: "Pant 08",
    image: "assets/images/pant-08.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 9,
    name: "Pant 09",
    image: "assets/images/pant-09.jpg",
    position: "center 60%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 10,
    name: "Pant 10",
    image: "assets/images/pant-10.jpg",
    position: "center 60%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 11,
    name: "Pant 11",
    image: "assets/images/pant-11.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 12,
    name: "Pant 12",
    image: "assets/images/pant-12.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 13,
    name: "Pant 13",
    image: "assets/images/pant-13.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  },
  {
    id: 14,
    name: "Pant 14",
    image: "assets/images/pant-14.jpg",
    position: "center 55%",
    description: "",
    specs: { "Fabric": "", "Composition": "", "Fit": "", "Colour": "", "Wash / Finish": "", "Size Range": "", "MOQ": "", "Packing": "" }
  }
];
